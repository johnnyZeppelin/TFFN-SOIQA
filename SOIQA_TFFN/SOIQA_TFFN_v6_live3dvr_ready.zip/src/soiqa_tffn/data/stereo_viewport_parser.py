from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from PIL import Image


@dataclass
class StereoParserConfig:
    packing_mode: str
    input_size: int
    resize_split_halves_back: bool = True
    separate_file_suffix_left: str = "_L"
    separate_file_suffix_right: str = "_R"
    top_bottom_order: str = "top_left_bottom_right"
    left_right_order: str = "left_left_right_right"


class StereoViewportParser:
    def __init__(self, cfg: StereoParserConfig) -> None:
        self.cfg = cfg

    def _resize_if_needed(self, image: Image.Image) -> Image.Image:
        if self.cfg.resize_split_halves_back:
            return image.resize((self.cfg.input_size, self.cfg.input_size), Image.BILINEAR)
        return image

    def _load_image(self, image_path: str | Path) -> Image.Image:
        return Image.open(image_path).convert("RGB")

    def parse_packed(self, image_path: str | Path) -> tuple[Image.Image, Image.Image]:
        image = self._load_image(image_path)
        w, h = image.size
        if self.cfg.packing_mode == "top_bottom":
            top = image.crop((0, 0, w, h // 2))
            bottom = image.crop((0, h // 2, w, h))
            if self.cfg.top_bottom_order == "top_left_bottom_right":
                left, right = top, bottom
            elif self.cfg.top_bottom_order == "top_right_bottom_left":
                left, right = bottom, top
            else:
                raise ValueError(f"Unsupported top_bottom_order: {self.cfg.top_bottom_order}")
            return self._resize_if_needed(left), self._resize_if_needed(right)
        if self.cfg.packing_mode == "left_right":
            left_half = image.crop((0, 0, w // 2, h))
            right_half = image.crop((w // 2, 0, w, h))
            if self.cfg.left_right_order == "left_left_right_right":
                left, right = left_half, right_half
            elif self.cfg.left_right_order == "left_right_right_left":
                left, right = right_half, left_half
            else:
                raise ValueError(f"Unsupported left_right_order: {self.cfg.left_right_order}")
            return self._resize_if_needed(left), self._resize_if_needed(right)
        raise ValueError(f"Unsupported packing mode for packed stereo: {self.cfg.packing_mode}")

    def parse_separate(self, image_path: str | Path) -> tuple[Image.Image, Image.Image]:
        image_path = Path(image_path)
        left_path = image_path.with_name(image_path.stem + self.cfg.separate_file_suffix_left + image_path.suffix)
        right_path = image_path.with_name(image_path.stem + self.cfg.separate_file_suffix_right + image_path.suffix)
        if not left_path.exists() or not right_path.exists():
            raise FileNotFoundError(f"Expected separate stereo files but missing: {left_path} or {right_path}")
        left = self._load_image(left_path)
        right = self._load_image(right_path)
        return self._resize_if_needed(left), self._resize_if_needed(right)

    def parse_explicit_pair(self, entry: Mapping[str, str]) -> tuple[Image.Image, Image.Image]:
        left_path = Path(entry["left"])
        right_path = Path(entry["right"])
        if not left_path.exists() or not right_path.exists():
            raise FileNotFoundError(f"Missing explicit stereo files: {left_path} or {right_path}")
        left = self._load_image(left_path)
        right = self._load_image(right_path)
        return self._resize_if_needed(left), self._resize_if_needed(right)

    def __call__(self, image_entry: str | Path | Mapping[str, str]) -> tuple[Image.Image, Image.Image]:
        if isinstance(image_entry, Mapping):
            return self.parse_explicit_pair(image_entry)
        if self.cfg.packing_mode in {"top_bottom", "left_right"}:
            return self.parse_packed(image_entry)
        if self.cfg.packing_mode == "separate_files":
            return self.parse_separate(image_entry)
        if self.cfg.packing_mode == "nested_left_right":
            raise ValueError(
                "nested_left_right mode expects manifest entries with explicit {'left', 'right'} paths. "
                "Please rebuild the manifest with the updated manifest builder."
            )
        raise ValueError(f"Unknown stereo packing mode: {self.cfg.packing_mode}")

from __future__ import annotations

import random
from typing import Any, Callable

import numpy as np
import torch
from PIL import Image, ImageEnhance


class Compose:
    def __init__(self, transforms: list[Callable]) -> None:
        self.transforms = transforms

    def __call__(self, image):
        for transform in self.transforms:
            image = transform(image)
        return image


class Resize:
    def __init__(self, size: tuple[int, int]) -> None:
        self.size = size

    def __call__(self, image: Image.Image) -> Image.Image:
        return image.resize(self.size, Image.BILINEAR)


class RandomHorizontalFlip:
    def __init__(self, p: float = 0.5) -> None:
        self.p = p

    def __call__(self, image: Image.Image) -> Image.Image:
        if random.random() < self.p:
            return image.transpose(Image.FLIP_LEFT_RIGHT)
        return image


class ColorJitter:
    def __init__(self, brightness: float = 0.1, contrast: float = 0.1, saturation: float = 0.1) -> None:
        self.brightness = brightness
        self.contrast = contrast
        self.saturation = saturation

    def __call__(self, image: Image.Image) -> Image.Image:
        if self.brightness > 0:
            factor = 1.0 + random.uniform(-self.brightness, self.brightness)
            image = ImageEnhance.Brightness(image).enhance(factor)
        if self.contrast > 0:
            factor = 1.0 + random.uniform(-self.contrast, self.contrast)
            image = ImageEnhance.Contrast(image).enhance(factor)
        if self.saturation > 0:
            factor = 1.0 + random.uniform(-self.saturation, self.saturation)
            image = ImageEnhance.Color(image).enhance(factor)
        return image


class ToTensor:
    def __call__(self, image: Image.Image) -> torch.Tensor:
        array = np.asarray(image, dtype=np.float32) / 255.0
        if array.ndim == 2:
            array = np.stack([array, array, array], axis=-1)
        tensor = torch.from_numpy(array).permute(2, 0, 1).contiguous()
        return tensor


class Normalize:
    def __init__(self, mean: list[float], std: list[float]) -> None:
        self.mean = torch.tensor(mean, dtype=torch.float32).view(-1, 1, 1)
        self.std = torch.tensor(std, dtype=torch.float32).view(-1, 1, 1)

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        return (tensor - self.mean) / self.std


def build_transforms(cfg: dict[str, Any], is_train: bool):
    dataset_cfg = cfg["dataset"]
    input_size = int(dataset_cfg["input_size"])
    mean = dataset_cfg["normalization"]["mean"]
    std = dataset_cfg["normalization"]["std"]
    aug_cfg = dataset_cfg.get("augment", {})

    ops: list[Callable] = [Resize((input_size, input_size))]
    if is_train and aug_cfg.get("train_hflip", False):
        ops.append(RandomHorizontalFlip(p=0.5))
    if is_train and aug_cfg.get("color_jitter", False):
        ops.append(ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1))
    ops.extend([ToTensor(), Normalize(mean=mean, std=std)])
    return Compose(ops)

from __future__ import annotations

import json
from typing import Any

import pandas as pd
import torch
from torch.utils.data import Dataset

from soiqa_tffn.data.stereo_viewport_parser import StereoParserConfig, StereoViewportParser
from soiqa_tffn.data.transforms import build_transforms


class Live3DVRDataset(Dataset):
    def __init__(self, manifest_path: str, cfg: dict[str, Any], is_train: bool = True) -> None:
        super().__init__()
        self.cfg = cfg
        self.df = pd.read_csv(manifest_path)
        self.transform = build_transforms(cfg, is_train=is_train)
        dataset_cfg = cfg["dataset"]
        self.num_viewports = int(dataset_cfg["num_viewports"])
        self.load_left_restored_for_debug = bool(dataset_cfg.get("load_left_restored_for_debug", False))
        self.parser = StereoViewportParser(
            StereoParserConfig(
                packing_mode=dataset_cfg["stereo_packing_mode"],
                input_size=int(dataset_cfg["input_size"]),
                resize_split_halves_back=bool(dataset_cfg.get("resize_split_halves_back", True)),
                separate_file_suffix_left=dataset_cfg.get("separate_file_suffix_left", "_L"),
                separate_file_suffix_right=dataset_cfg.get("separate_file_suffix_right", "_R"),
                top_bottom_order=dataset_cfg.get("top_bottom_order", "top_left_bottom_right"),
                left_right_order=dataset_cfg.get("left_right_order", "left_left_right_right"),
            )
        )

    def __len__(self) -> int:
        return len(self.df)

    def _load_viewport_set(self, paths_json: str, need_left: bool = True, need_right: bool = True) -> tuple[list[torch.Tensor] | None, list[torch.Tensor] | None]:
        left_tensors: list[torch.Tensor] | None = [] if need_left else None
        right_tensors: list[torch.Tensor] | None = [] if need_right else None
        entries = json.loads(paths_json)
        if len(entries) != self.num_viewports:
            raise ValueError(f"Expected {self.num_viewports} viewports, but got {len(entries)}")
        for entry in entries:
            left, right = self.parser(entry)
            if need_left and left_tensors is not None:
                left_tensors.append(self.transform(left))
            if need_right and right_tensors is not None:
                right_tensors.append(self.transform(right))
        return left_tensors, right_tensors

    def __getitem__(self, index: int) -> dict[str, Any]:
        row = self.df.iloc[index]
        distorted_left, distorted_right = self._load_viewport_set(row["distorted_viewports_json"], need_left=True, need_right=True)
        _, restored_right = self._load_viewport_set(row["restored_viewports_json"], need_left=False, need_right=True)

        sample = {
            "image_name": row["image_name"],
            "stem": row["stem"],
            "content_name": row.get("content_name", ""),
            "distortion_type": row.get("distortion_type", ""),
            "distortion_level": str(row.get("distortion_level", "")),
            "left_viewports": torch.stack(distorted_left or [], dim=0),
            "right_viewports": torch.stack(distorted_right or [], dim=0),
            "right_restored_viewports": torch.stack(restored_right or [], dim=0),
            "score": torch.tensor(float(row["dmos"]), dtype=torch.float32),
        }

        if self.load_left_restored_for_debug:
            restored_left, _ = self._load_viewport_set(row["restored_viewports_json"], need_left=True, need_right=False)
            sample["left_restored_viewports"] = torch.stack(restored_left or [], dim=0)
        return sample

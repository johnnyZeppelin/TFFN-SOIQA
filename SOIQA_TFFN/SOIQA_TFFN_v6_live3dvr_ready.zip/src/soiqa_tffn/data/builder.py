from __future__ import annotations

from typing import Any

from torch.utils.data import DataLoader

from soiqa_tffn.data.collate import soiqa_collate_fn
from soiqa_tffn.data.datasets import Live3DVRDataset


def build_dataset(cfg: dict[str, Any], manifest_path: str, is_train: bool):
    return Live3DVRDataset(manifest_path=manifest_path, cfg=cfg, is_train=is_train)


def build_dataloader(cfg: dict[str, Any], manifest_path: str, is_train: bool) -> DataLoader:
    dataset = build_dataset(cfg, manifest_path=manifest_path, is_train=is_train)
    batch_size = int(cfg["train"]["batch_size"] if is_train else cfg["eval"]["batch_size"])
    num_workers = int(cfg["project"].get("num_workers", 4))
    persistent_workers = bool(cfg["project"].get("persistent_workers", True)) and num_workers > 0
    pin_memory = bool(cfg["project"].get("pin_memory", True))
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=is_train,
        num_workers=num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
        drop_last=is_train,
        collate_fn=soiqa_collate_fn,
    )

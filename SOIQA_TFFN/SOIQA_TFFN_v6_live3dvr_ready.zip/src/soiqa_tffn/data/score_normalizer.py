from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import torch


@dataclass
class ScoreNormalizer:
    mode: str = "none"
    mean: float = 0.0
    std: float = 1.0
    min_value: float = 0.0
    max_value: float = 1.0
    eps: float = 1e-8

    @classmethod
    def fit(cls, values: Iterable[float], mode: str = "none", eps: float = 1e-8) -> "ScoreNormalizer":
        arr = np.asarray(list(values), dtype=np.float64)
        if arr.size == 0:
            raise ValueError("Cannot fit score normalizer on empty values.")
        mode = str(mode).lower()
        mean = float(arr.mean())
        std = float(arr.std())
        min_value = float(arr.min())
        max_value = float(arr.max())
        if mode == "zscore" and std < eps:
            std = 1.0
        if mode == "minmax" and abs(max_value - min_value) < eps:
            max_value = min_value + 1.0
        if mode not in {"none", "zscore", "minmax"}:
            raise ValueError(f"Unsupported score normalization mode: {mode}")
        return cls(mode=mode, mean=mean, std=std, min_value=min_value, max_value=max_value, eps=eps)

    @property
    def is_enabled(self) -> bool:
        return self.mode != "none"

    def transform_array(self, values: np.ndarray) -> np.ndarray:
        if self.mode == "none":
            return values
        if self.mode == "zscore":
            return (values - self.mean) / max(self.std, self.eps)
        if self.mode == "minmax":
            return (values - self.min_value) / max(self.max_value - self.min_value, self.eps)
        raise ValueError(f"Unsupported score normalization mode: {self.mode}")

    def inverse_array(self, values: np.ndarray) -> np.ndarray:
        if self.mode == "none":
            return values
        if self.mode == "zscore":
            return values * max(self.std, self.eps) + self.mean
        if self.mode == "minmax":
            return values * max(self.max_value - self.min_value, self.eps) + self.min_value
        raise ValueError(f"Unsupported score normalization mode: {self.mode}")

    def transform_tensor(self, values: torch.Tensor) -> torch.Tensor:
        if self.mode == "none":
            return values
        if self.mode == "zscore":
            return (values - self.mean) / max(self.std, self.eps)
        if self.mode == "minmax":
            return (values - self.min_value) / max(self.max_value - self.min_value, self.eps)
        raise ValueError(f"Unsupported score normalization mode: {self.mode}")

    def inverse_tensor(self, values: torch.Tensor) -> torch.Tensor:
        if self.mode == "none":
            return values
        if self.mode == "zscore":
            return values * max(self.std, self.eps) + self.mean
        if self.mode == "minmax":
            return values * max(self.max_value - self.min_value, self.eps) + self.min_value
        raise ValueError(f"Unsupported score normalization mode: {self.mode}")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScoreNormalizer":
        return cls(**data)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "ScoreNormalizer":
        path = Path(path)
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls.from_dict(data)

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import pandas as pd


@dataclass
class SplitResult:
    train_df: pd.DataFrame
    test_df: pd.DataFrame


def _split_by_indices(df: pd.DataFrame, train_indices: list[int], test_indices: list[int]) -> SplitResult:
    train_df = df.iloc[train_indices].copy().reset_index(drop=True)
    test_df = df.iloc[test_indices].copy().reset_index(drop=True)
    return SplitResult(train_df=train_df, test_df=test_df)


def _random_split(df: pd.DataFrame, train_ratio: float, seed: int, shuffle: bool) -> SplitResult:
    if shuffle:
        df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    train_size = int(len(df) * train_ratio)
    train_df = df.iloc[:train_size].copy().reset_index(drop=True)
    test_df = df.iloc[train_size:].copy().reset_index(drop=True)
    return SplitResult(train_df=train_df, test_df=test_df)


def _group_split(df: pd.DataFrame, train_ratio: float, seed: int, group_col: str) -> SplitResult:
    if group_col not in df.columns:
        raise KeyError(f"Split strategy requires group column: {group_col}")
    groups = sorted(df[group_col].dropna().astype(str).unique().tolist())
    if not groups:
        return _random_split(df, train_ratio=train_ratio, seed=seed, shuffle=True)
    group_series = pd.Series(groups)
    group_series = group_series.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    train_group_count = max(1, int(len(group_series) * train_ratio))
    train_groups = set(group_series.iloc[:train_group_count].tolist())
    train_mask = df[group_col].astype(str).isin(train_groups)
    if train_mask.all() or (~train_mask).all():
        return _random_split(df, train_ratio=train_ratio, seed=seed, shuffle=True)
    train_df = df.loc[train_mask].copy().reset_index(drop=True)
    test_df = df.loc[~train_mask].copy().reset_index(drop=True)
    return SplitResult(train_df=train_df, test_df=test_df)


def split_manifest_dataframe(
    cfg: dict[str, Any],
    df: pd.DataFrame,
    *,
    strategy: str | None = None,
    train_ratio: float | None = None,
    seed: int | None = None,
    shuffle: bool | None = None,
    group_col: str | None = None,
) -> SplitResult:
    split_cfg = cfg["split"]
    strategy = str(strategy or split_cfg.get("strategy", "random")).lower()
    train_ratio = float(train_ratio if train_ratio is not None else split_cfg.get("train_ratio", 0.8))
    seed = int(seed if seed is not None else split_cfg.get("seed", 3407))
    shuffle = bool(shuffle if shuffle is not None else split_cfg.get("shuffle", True))
    group_col = str(group_col or split_cfg.get("group_col", "content_name"))

    if strategy == "random":
        return _random_split(df, train_ratio=train_ratio, seed=seed, shuffle=shuffle)
    if strategy in {"by_content", "group", "grouped"}:
        return _group_split(df, train_ratio=train_ratio, seed=seed, group_col=group_col)
    raise ValueError(f"Unsupported split strategy: {strategy}")


def summarize_split(train_df: pd.DataFrame, test_df: pd.DataFrame) -> dict[str, Any]:
    def _branch_summary(branch: pd.DataFrame) -> dict[str, Any]:
        summary = {
            "num_samples": int(len(branch)),
        }
        if "content_name" in branch.columns:
            summary["num_contents"] = int(branch["content_name"].nunique(dropna=True))
        if "distortion_type" in branch.columns:
            summary["distortion_counts"] = {
                str(k): int(v) for k, v in branch["distortion_type"].value_counts(dropna=False).to_dict().items()
            }
        return summary

    overlap_contents: list[str] = []
    if "content_name" in train_df.columns and "content_name" in test_df.columns:
        overlap_contents = sorted(
            set(train_df["content_name"].dropna().astype(str))
            & set(test_df["content_name"].dropna().astype(str))
        )
    return {
        "train": _branch_summary(train_df),
        "test": _branch_summary(test_df),
        "content_overlap_count": len(overlap_contents),
        "content_overlap_preview": overlap_contents[:20],
    }


def save_split_summary(summary: dict[str, Any], summary_path: str | Path) -> None:
    summary_path = Path(summary_path)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

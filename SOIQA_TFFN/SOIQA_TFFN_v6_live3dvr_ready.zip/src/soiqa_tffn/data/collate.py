from __future__ import annotations

from typing import Any

import torch


OPTIONAL_TENSOR_KEYS = (
    "left_restored_viewports",
)

OPTIONAL_TEXT_KEYS = (
    "content_name",
    "distortion_type",
    "distortion_level",
)


def soiqa_collate_fn(batch: list[dict[str, Any]]) -> dict[str, Any]:
    out = {
        "image_name": [item["image_name"] for item in batch],
        "stem": [item["stem"] for item in batch],
        "left_viewports": torch.stack([item["left_viewports"] for item in batch], dim=0),
        "right_viewports": torch.stack([item["right_viewports"] for item in batch], dim=0),
        "right_restored_viewports": torch.stack([item["right_restored_viewports"] for item in batch], dim=0),
        "score": torch.stack([item["score"] for item in batch], dim=0),
    }
    for key in OPTIONAL_TENSOR_KEYS:
        if key in batch[0]:
            out[key] = torch.stack([item[key] for item in batch], dim=0)
    for key in OPTIONAL_TEXT_KEYS:
        if key in batch[0]:
            out[key] = [str(item.get(key, "")) for item in batch]
    return out

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any


@dataclass
class Live3DVRNameMeta:
    image_name: str
    stem: str
    content_name: str
    distortion_type: str
    distortion_level: int | None
    distortion_token: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def parse_live3dvr_image_name(image_name: str) -> Live3DVRNameMeta:
    stem = Path(image_name).stem
    tokens = stem.split("_")
    if len(tokens) >= 3 and tokens[-1].isdigit():
        content_name = "_".join(tokens[:-2]) or stem
        distortion_token = tokens[-2]
        distortion_type = distortion_token.lower()
        distortion_level = int(tokens[-1])
    elif len(tokens) >= 2:
        content_name = "_".join(tokens[:-1]) or stem
        distortion_token = tokens[-1]
        distortion_type = distortion_token.lower()
        distortion_level = None
    else:
        content_name = stem
        distortion_token = None
        distortion_type = "unknown"
        distortion_level = None
    return Live3DVRNameMeta(
        image_name=image_name,
        stem=stem,
        content_name=content_name,
        distortion_type=distortion_type,
        distortion_level=distortion_level,
        distortion_token=distortion_token,
    )

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from soiqa_tffn.config import load_config
from soiqa_tffn.data.metadata import parse_live3dvr_image_name
from soiqa_tffn.utils.io import ensure_dir
from soiqa_tffn.utils.misc import stem_from_image_name


@dataclass
class ManifestIssue:
    stem: str
    kind: str
    detail: str


ViewportEntry = str | dict[str, str]


def _candidate_packed_viewport_paths(base_dir: Path, stem: str, fov_idx: int, suffix: str = "", ext: str = ".png") -> list[Path]:
    filename = f"{stem}_fov{fov_idx}{suffix}{ext}"
    return [
        base_dir / filename,
        base_dir / stem / filename,
    ]


def _find_packed_viewport_file(base_dir: Path, stem: str, fov_idx: int, suffix: str = "", ext: str = ".png") -> Path | None:
    for path in _candidate_packed_viewport_paths(base_dir, stem, fov_idx, suffix=suffix, ext=ext):
        if path.exists():
            return path
    return None


def _find_nested_lr_pair(
    base_dir: Path,
    stem: str,
    fov_idx: int,
    *,
    suffix: str,
    ext: str,
    left_dir_name: str,
    right_dir_name: str,
) -> dict[str, str] | None:
    left_name = f"{stem}_left_{fov_idx:02d}{suffix}{ext}"
    right_name = f"{stem}_right_{fov_idx:02d}{suffix}{ext}"
    left_path = base_dir / stem / left_dir_name / left_name
    right_path = base_dir / stem / right_dir_name / right_name
    if left_path.exists() and right_path.exists():
        return {"left": str(left_path), "right": str(right_path)}
    return None


def _collect_viewports(
    base_dir: Path,
    stem: str,
    num_viewports: int,
    *,
    dataset_cfg: dict[str, Any],
    suffix: str,
    issues: list[ManifestIssue],
) -> list[ViewportEntry]:
    layout = str(dataset_cfg.get("stereo_packing_mode", "top_bottom")).lower()
    ext = str(dataset_cfg.get("viewport_ext", ".png"))
    found_entries: list[ViewportEntry] = []

    if layout == "nested_left_right":
        left_dir_name = str(dataset_cfg.get("left_dir_name", "left"))
        right_dir_name = str(dataset_cfg.get("right_dir_name", "right"))
        for i in range(1, num_viewports + 1):
            pair = _find_nested_lr_pair(
                base_dir,
                stem,
                i,
                suffix=suffix,
                ext=ext,
                left_dir_name=left_dir_name,
                right_dir_name=right_dir_name,
            )
            if pair is None:
                issues.append(ManifestIssue(stem=stem, kind="missing_viewport_pair", detail=f"fov{i:02d}{suffix}"))
                continue
            found_entries.append(pair)
        return found_entries

    for i in range(1, num_viewports + 1):
        path = _find_packed_viewport_file(base_dir, stem, i, suffix=suffix, ext=ext)
        if path is None:
            issues.append(ManifestIssue(stem=stem, kind="missing_viewport", detail=f"fov{i}{suffix}"))
            continue
        found_entries.append(str(path))
    return found_entries


def _entry_exists(entry: ViewportEntry) -> tuple[bool, str | None]:
    if isinstance(entry, str):
        path = Path(entry)
        return path.exists(), None if path.exists() else str(path)
    left_path = Path(entry.get("left", ""))
    right_path = Path(entry.get("right", ""))
    missing = []
    if not left_path.exists():
        missing.append(str(left_path))
    if not right_path.exists():
        missing.append(str(right_path))
    return len(missing) == 0, "; ".join(missing) if missing else None


def _validate_entries(stem: str, kind: str, entries: list[ViewportEntry], num_viewports: int) -> list[ManifestIssue]:
    issues: list[ManifestIssue] = []
    if len(entries) != num_viewports:
        issues.append(ManifestIssue(stem=stem, kind=f"{kind}_count_mismatch", detail=f"expected={num_viewports}, found={len(entries)}"))
    for idx, entry in enumerate(entries, start=1):
        exists, detail = _entry_exists(entry)
        if not exists:
            issues.append(ManifestIssue(stem=stem, kind=f"missing_{kind}_entry", detail=f"fov{idx:02d}: {detail}"))
    return issues


def validate_manifest_dataframe(df: pd.DataFrame, expected_viewports: int) -> list[ManifestIssue]:
    issues: list[ManifestIssue] = []
    if df.empty:
        issues.append(ManifestIssue(stem="<manifest>", kind="empty_manifest", detail="No valid samples were written."))
        return issues
    for _, row in df.iterrows():
        distorted = json.loads(row["distorted_viewports_json"])
        restored = json.loads(row["restored_viewports_json"])
        issues.extend(_validate_entries(str(row["stem"]), "distorted", distorted, expected_viewports))
        issues.extend(_validate_entries(str(row["stem"]), "restored", restored, expected_viewports))
    return issues


def _build_row(
    image_name: str,
    score: float,
    full_image_path: Path,
    restored_full_image_path: Path,
    distorted_paths: list[ViewportEntry],
    restored_paths: list[ViewportEntry],
    dataset_cfg: dict[str, Any],
) -> dict[str, Any]:
    meta = parse_live3dvr_image_name(image_name)
    return {
        "image_name": image_name,
        "stem": meta.stem,
        "content_name": meta.content_name,
        "distortion_type": meta.distortion_type,
        "distortion_level": meta.distortion_level,
        "distortion_token": meta.distortion_token,
        "dmos": score,
        "num_viewports": len(distorted_paths),
        "has_full_image": bool(full_image_path.exists()),
        "full_image_path": str(full_image_path),
        "has_restored_full_image": bool(restored_full_image_path.exists()),
        "restored_full_image_path": str(restored_full_image_path),
        "distorted_viewports_json": json.dumps(distorted_paths, ensure_ascii=False),
        "restored_viewports_json": json.dumps(restored_paths, ensure_ascii=False),
        "stereo_packing_mode": dataset_cfg["stereo_packing_mode"],
    }


def build_live3dvr_manifest(cfg: dict[str, Any]) -> pd.DataFrame:
    paths_cfg = cfg["paths"]
    manifest_cfg = cfg["manifest"]
    dataset_cfg = cfg["dataset"]

    csv_path = Path(paths_cfg["csv_path"])
    viewport_dir = Path(paths_cfg["viewport_dir"])
    restored_viewport_dir = Path(paths_cfg["restored_viewport_dir"])
    live3dvr_dir = Path(paths_cfg["live3dvr_dir"])
    restored_live3dvr_dir = Path(paths_cfg.get("restored_live3dvr_dir", "")) if paths_cfg.get("restored_live3dvr_dir") else Path()

    df = pd.read_csv(csv_path)
    image_col = manifest_cfg["image_name_col"]
    score_col = manifest_cfg["score_col"]
    num_viewports = int(manifest_cfg["num_viewports"])
    strict_check = bool(manifest_cfg.get("strict_check", True))
    restored_suffix = manifest_cfg.get("restored_suffix", "_r")
    allow_missing_full_image = bool(manifest_cfg.get("allow_missing_full_image", True))
    allow_missing_restored_full_image = bool(manifest_cfg.get("allow_missing_restored_full_image", True))

    rows: list[dict[str, Any]] = []
    issues: list[ManifestIssue] = []

    for _, row in df.iterrows():
        image_name = str(row[image_col])
        score = float(row[score_col])
        stem = stem_from_image_name(image_name)
        full_image_path = live3dvr_dir / image_name
        restored_full_name = f"{stem}{restored_suffix}{Path(image_name).suffix}"
        restored_full_image_path = restored_live3dvr_dir / restored_full_name if str(restored_live3dvr_dir) not in {"", "."} else Path(restored_full_name)

        if (not allow_missing_full_image) and (not full_image_path.exists()):
            issues.append(ManifestIssue(stem=stem, kind="missing_full_image", detail=str(full_image_path)))
            continue
        if (not allow_missing_restored_full_image) and (not restored_full_image_path.exists()):
            issues.append(ManifestIssue(stem=stem, kind="missing_restored_full_image", detail=str(restored_full_image_path)))
            continue

        distorted_paths = _collect_viewports(
            viewport_dir,
            stem,
            num_viewports,
            dataset_cfg=dataset_cfg,
            suffix="",
            issues=issues,
        )
        restored_paths = _collect_viewports(
            restored_viewport_dir,
            stem,
            num_viewports,
            dataset_cfg=dataset_cfg,
            suffix=restored_suffix,
            issues=issues,
        )
        issues.extend(_validate_entries(stem, "distorted", distorted_paths, num_viewports))
        issues.extend(_validate_entries(stem, "restored", restored_paths, num_viewports))

        sample_ok = len(distorted_paths) == num_viewports and len(restored_paths) == num_viewports
        if not sample_ok:
            continue

        rows.append(
            _build_row(
                image_name=image_name,
                score=score,
                full_image_path=full_image_path,
                restored_full_image_path=restored_full_image_path,
                distorted_paths=distorted_paths,
                restored_paths=restored_paths,
                dataset_cfg=dataset_cfg,
            )
        )

    manifest_df = pd.DataFrame(rows)
    if not manifest_df.empty:
        manifest_df = manifest_df.sort_values(
            by=["content_name", "distortion_type", "distortion_level", "image_name"],
            kind="stable",
            na_position="last",
        ).reset_index(drop=True)

    validation_issues = validate_manifest_dataframe(manifest_df, expected_viewports=num_viewports)
    issues.extend(validation_issues)

    out_path = Path(paths_cfg["manifest_path"])
    ensure_dir(out_path.parent)
    manifest_df.to_csv(out_path, index=False)

    issues_path = out_path.with_name(out_path.stem + "_issues.csv")
    if issues:
        pd.DataFrame([{"stem": x.stem, "kind": x.kind, "detail": x.detail} for x in issues]).to_csv(issues_path, index=False)
        if strict_check:
            preview = "\n".join(f"{x.stem} | {x.kind} | {x.detail}" for x in issues[:20])
            raise FileNotFoundError(f"Manifest build failed with {len(issues)} issues. Preview:\n{preview}")
    elif issues_path.exists():
        issues_path.unlink()

    return manifest_df


def summarize_manifest(manifest_df: pd.DataFrame) -> dict[str, Any]:
    if manifest_df.empty:
        return {
            "num_samples": 0,
            "num_contents": 0,
            "distortion_counts": {},
            "distortion_level_counts": {},
        }
    distortion_counts = manifest_df["distortion_type"].value_counts(dropna=False).to_dict()
    level_counts = (
        manifest_df["distortion_level"].fillna("NA").astype(str).value_counts(dropna=False).to_dict()
    )
    return {
        "num_samples": int(len(manifest_df)),
        "num_contents": int(manifest_df["content_name"].nunique(dropna=True)),
        "distortion_counts": {str(k): int(v) for k, v in distortion_counts.items()},
        "distortion_level_counts": {str(k): int(v) for k, v in level_counts.items()},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    df = build_live3dvr_manifest(cfg)
    summary = summarize_manifest(df)
    print(f"Manifest written with {len(df)} samples to {cfg['paths']['manifest_path']}")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
